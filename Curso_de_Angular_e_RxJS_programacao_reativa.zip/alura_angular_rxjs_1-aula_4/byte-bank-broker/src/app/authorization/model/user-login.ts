export interface UserLogin {
  userName: string;
  password: string;
  remindUser: boolean;
}
